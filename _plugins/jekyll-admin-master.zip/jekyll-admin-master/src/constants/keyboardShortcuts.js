export default {
  save: 'mod+s',
};
