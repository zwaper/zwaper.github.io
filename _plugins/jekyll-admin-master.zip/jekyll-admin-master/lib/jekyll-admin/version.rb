# frozen_string_literal: true

module JekyllAdmin
  VERSION = "0.11.0"
end
