// TODO:
// -------------------------------
// import * as da from './da';
// import * as es from './es';
// import * as fr from './fr';
// import * as ptBr from './ptBr';
// import * as sv from './sv';

import * as en from './en';

const translations = en; // TODO: select language
export default translations;
